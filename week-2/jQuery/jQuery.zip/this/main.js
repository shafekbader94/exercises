$("#b1").hover(function () {
  console.log($(this))
})