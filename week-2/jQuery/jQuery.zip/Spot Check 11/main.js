
  const removeElemnt = function () {
    $("#remove").remove()
  }
  
  $("#remove").hover(removeElemnt)


 