
$("#b1").addClass("box")
$("#b2").addClass("box")