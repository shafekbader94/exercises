$("p").remove()
$("p").remove(".brown")