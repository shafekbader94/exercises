const color = $("div").data().color  
console.log(color) //prints #2980b9