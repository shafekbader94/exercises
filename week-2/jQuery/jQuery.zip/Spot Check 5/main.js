const printInfo = $("div").data()

console.log("The item with barcode " + printInfo.barcode + " will expire on " + printInfo.expirationdate) 