
  const myInput = function () {
    console.log($("#my-input").val())
  }
  
  $("button").click(myInput)


