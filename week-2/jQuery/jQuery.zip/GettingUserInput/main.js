$('#my-input').val("Terabyte")
//$('#my-input').val()