
  const changeColor = function () {
   $(this).css("background-color" , "blue")
  }
  
  $("div").hover(changeColor)


