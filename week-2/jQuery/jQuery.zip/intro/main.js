document.getElementById("container")

$("#container")

/** */
//vanilla JS
document.getElementById("container").style.display = "none" 

//jQuery
$("#container").hide() //when we select elements with jQuery, we also get methods that can work on the element, on top of the element itself