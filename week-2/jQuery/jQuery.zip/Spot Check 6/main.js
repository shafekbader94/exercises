
  const hoverBlue = function () {
    $(".blue-div").css("background-color" , "blue")
  }
  
  $(".blue-div").hover(hoverBlue)


